package com.christian.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SensorAcelerometro extends AppCompatActivity implements SensorEventListener
{
    private SensorManager sensorManager;
   //tipo dado boleano para alterar a cor
    private boolean isColor = false;
    private TextView re1, re2, re3, re4, re5, re6, re7, re8, re9, re10, re11, re12, re13, re14, re15;
    private Button bVoltar;
    //long é igual ao double, porem armazena mais numeros decimais
    private long ultimaAtualizacao;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_acelerometro);

        re1 = findViewById(R.id.re1);
        re2 = findViewById(R.id.re2);
        re3 = findViewById(R.id.re3);
        re4 = findViewById(R.id.re4);
        re5 = findViewById(R.id.re5);
        re6 = findViewById(R.id.re6);
        re7 = findViewById(R.id.re7);
        re8 = findViewById(R.id.re8);
        re9 = findViewById(R.id.re9);
        re10 = findViewById(R.id.re10);
        re11 = findViewById(R.id.re11);
        re12 = findViewById(R.id.re12);
        re13= findViewById(R.id.re13);
        re14 = findViewById(R.id.re14);
        re15 = findViewById(R.id.re15);
        re1.setBackgroundColor(Color.MAGENTA);
        re2.setBackgroundColor(Color.RED);
        re3.setBackgroundColor(Color.GREEN);
        re4.setBackgroundColor(Color.GRAY);
        re5.setBackgroundColor(Color.DKGRAY);
        re6.setBackgroundColor(Color.YELLOW);
        re7.setBackgroundColor(Color.MAGENTA);
        re8.setBackgroundColor(Color.LTGRAY);
        re9.setBackgroundColor(Color.CYAN);
        re8.setBackgroundColor(Color.BLACK);
        re10.setBackgroundColor(Color.LTGRAY);
        re11.setBackgroundColor(Color.CYAN);
        re12.setBackgroundColor(Color.YELLOW);
        re13.setBackgroundColor(Color.MAGENTA);
        re14.setBackgroundColor(Color.BLACK);
        re15.setBackgroundColor(Color.DKGRAY);
        bVoltar = findViewById(R.id.bVoltar);
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        ultimaAtualizacao = System.currentTimeMillis();

        bVoltar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                voltarMenu();
            }
        });

    }

    private void voltarMenu()
    {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER);
        {
            getAccelerometer(event);
        }
    }

    private void getAccelerometer(SensorEvent event)
    {
        float[] values = event.values;
        //planos cartesiano de movimento
        // x = Horizontal
        float x = values[0];
        // y = Vertical
        float y = values[1];
        // z = Profundidade
        float z = values[2];

        float accelationSquareRoot = (x * x + y * y + z * z) / (sensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
        long tempoAtual = System.currentTimeMillis();

        Toast.makeText(getApplicationContext(), String.valueOf(accelationSquareRoot) + " " + SensorManager.GRAVITY_EARTH, Toast.LENGTH_SHORT).show();

        if(accelationSquareRoot >= 2)
        {
            if(tempoAtual - ultimaAtualizacao < 200)
            {
                return;
            }
            ultimaAtualizacao = tempoAtual;
            if(isColor)
            {
                re1.setBackgroundColor(Color.MAGENTA);
                re2.setBackgroundColor(Color.DKGRAY);
                re3.setBackgroundColor(Color.BLACK);
                re4.setBackgroundColor(Color.YELLOW);
                re5.setBackgroundColor(Color.CYAN);
                re6.setBackgroundColor(Color.LTGRAY);
                re7.setBackgroundColor(Color.BLUE);
                re8.setBackgroundColor(Color.GRAY);
                re9.setBackgroundColor(Color.GREEN);
                re10.setBackgroundColor(Color.RED);
                re11.setBackgroundColor(Color.BLUE);
                re12.setBackgroundColor(Color.MAGENTA);
                re13.setBackgroundColor(Color.DKGRAY);
                re14.setBackgroundColor(Color.BLACK);
                re15.setBackgroundColor(Color.YELLOW);
            }
            else
            {
                re1.setBackgroundColor(Color.YELLOW);
                re2.setBackgroundColor(Color.BLACK);
                re3.setBackgroundColor(Color.DKGRAY);
                re4.setBackgroundColor(Color.MAGENTA);
                re5.setBackgroundColor(Color.BLUE);
                re6.setBackgroundColor(Color.RED);
                re7.setBackgroundColor(Color.GREEN);
                re8.setBackgroundColor(Color.BLUE);
                re9.setBackgroundColor(Color.GRAY);
                re10.setBackgroundColor(Color.GREEN);
                re11.setBackgroundColor(Color.LTGRAY);
                re12.setBackgroundColor(Color.CYAN);
                re13.setBackgroundColor(Color.YELLOW);
                re14.setBackgroundColor(Color.GRAY);
                re15.setBackgroundColor(Color.BLUE);

            }

            isColor =! isColor;
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {

    }

    @Override
    public void onBackPressed()
    {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture)
    {

    }
}