package com.christian.meuprojeto;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.VelocityTracker;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private static MediaPlayer mpClique;
    private WebView imagem;
    private Button btnTchau, btnOi;
    private static final String DEBUG_TAG = "Velocity";
    private VelocityTracker mVelocityTracker = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imagem = findViewById(R.id.image);

        mpClique = MediaPlayer.create(this, R.raw.clique);


        WebSettings gif = imagem.getSettings();
        gif.setJavaScriptEnabled(true);



    }
}