package com.christian.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SensorProximidade extends AppCompatActivity implements SensorEventListener {
    private TextView resultado;
    private Sensor proximidade;
    private SensorManager medir;
    private Button btnVoltar;
    Vibrator vibrator;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        resultado = findViewById(R.id.resultado);
        btnVoltar = findViewById(R.id.btnVoltar);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }

    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        int valor = Math.round(sensorEvent.values[0]);

        if (sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            resultado.setText(" " + valor);

            if (valor >= 100) {
                vibrator.vibrate(200);
                return;
            }
            vibrator.vibrate(1000);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void abrirVoltar() {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
