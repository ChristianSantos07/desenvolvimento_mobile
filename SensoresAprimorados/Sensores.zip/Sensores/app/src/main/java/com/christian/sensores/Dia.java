package com.christian.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

public class Dia extends AppCompatActivity
{
    Button btnVoltarDia;
    private WebView imagem;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dia);

        imagem = findViewById(R.id.imagem);

        WebSettings gif = imagem.getSettings();
        gif.setJavaScriptEnabled(true);
        String caminho = "file:android_asset/planta.gif";
        imagem.loadUrl(caminho);

        btnVoltarDia = findViewById(R.id.btnVoltarDia);

        btnVoltarDia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                abrirVoltar();
            }
        });
    }

    private void abrirVoltar()
    {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }
}