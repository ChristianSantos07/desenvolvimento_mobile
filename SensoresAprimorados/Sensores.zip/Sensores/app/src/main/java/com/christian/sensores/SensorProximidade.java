package com.christian.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//DECLARAÇÃO DA CLASSE IMPLEMENTS COM A ABSTRAÇÃO DO SENSOREVENTLISTNER
public class SensorProximidade extends AppCompatActivity implements SensorEventListener
{
    //DECLARAÇÃO D
    private TextView resultado;
    private Sensor proximidade;
    private SensorManager medir;
    private Button btnVoltar;
    Vibrator vibrar;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        //MAPEAMENTO DE TODOS BOTOES DO LAYOUT
        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        resultado = findViewById(R.id.resultado);
        btnVoltar = findViewById(R.id.btnVoltar);
        vibrar = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        btnVoltar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                abrirVoltar();
            }
        });

    }

    //CHAMADA DE CALBACK, QUE TEM A FUNÇÃO DE DEFINIR O COMPORTAMENTO DO CICLO DE VIDA DAS ACTIVITYS
    @Override
    protected void onResume()
    {
        medir.registerListener(this, proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if(event.values[0] == 0)
        {
           getWindow().getDecorView().setBackgroundColor(Color.MAGENTA);
            resultado.setText("MUITOO PERTOO");
            abrirAlarme();
        }
        else
        {
            getWindow().getDecorView().setBackgroundColor(Color.CYAN);
            resultado.setText("MUITOO LONGEE");
        }
        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY)
        {


            if (event.values[0] == 0) {
                vibrar.vibrate(200);
                return;
            }
            else
            {
                vibrar.vibrate(1000);
            }
        }
    }

    public void abrirAlarme()
    {
        Intent janela = new Intent(this, Alarme.class);
        startActivity(janela);
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {

    }

    public void abrirVoltar() {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture)
    {

    }
}
