package com.christian.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SensorLuminosidade extends AppCompatActivity
{
    private TextView visual;
    SensorManager sm;
    SensorEventListener listener;
    Sensor luz;
    Button btnAce;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_luminosidade);

        visual = findViewById(R.id.visual);
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        luz = sm.getDefaultSensor(Sensor.TYPE_LIGHT);
        btnAce = findViewById(R.id.btnAce);

        btnAce.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                abriAcele();
            }
        });

        listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event)
            {
                visual.setText(String.valueOf(event.values[0]));
                int grayShade = (int) event.values[0];

                if(grayShade > 200) grayShade = 200;

                visual.setTextColor(Color.rgb( 255 - grayShade, 255 - grayShade, 255 - grayShade ) );
                visual.setBackgroundColor(Color.rgb(grayShade,grayShade,grayShade));

                if (grayShade >= 200)
                {
                    abrirDia();
                }

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i)
            {

            }
        };

        sm.registerListener(listener,luz,SensorManager.SENSOR_DELAY_FASTEST);

    };

    public void abrirDia()
    {
        Intent janela = new Intent(this, Dia.class);
        startActivity(janela);
    }

    public void abriAcele()
    {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }


    @Override
    protected void onPause()
    {

        sm.unregisterListener(listener, luz);
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }

}
