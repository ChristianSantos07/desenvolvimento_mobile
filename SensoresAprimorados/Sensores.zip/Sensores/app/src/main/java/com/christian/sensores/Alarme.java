package com.christian.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Alarme extends AppCompatActivity {
    Button btnVoltarAlarme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarme);

        btnVoltarAlarme = findViewById(R.id.btnVoltarDia);

        btnVoltarAlarme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltarAlarme();
            }
        });

        MainActivity.mp.start();
    }

    private void abrirVoltarAlarme()
    {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
        MainActivity.mp.stop();
    }
}